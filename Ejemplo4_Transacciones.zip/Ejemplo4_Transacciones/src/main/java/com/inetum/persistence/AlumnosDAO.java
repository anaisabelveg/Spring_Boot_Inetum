package com.inetum.persistence;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "alumnos", path = "alumnos")
public interface AlumnosDAO extends CrudRepository<Alumno, Long>{
	
	// http://localhost:8080/alumnos

}
