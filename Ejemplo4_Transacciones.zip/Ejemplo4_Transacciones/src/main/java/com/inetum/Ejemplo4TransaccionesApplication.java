package com.inetum;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.inetum.persistence.Alumno;
import com.inetum.persistence.AlumnosDAO;

@SpringBootApplication
public class Ejemplo4TransaccionesApplication implements CommandLineRunner{
	
	@Autowired
	private AlumnosDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo4TransaccionesApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		List<Alumno> lista = new ArrayList<>();
		lista.add(new Alumno(1L, "Maria", "Lopez", 9.2));
		lista.add(new Alumno(2L, "Juan", "Gutierrez", 9.2));
		lista.add(new Alumno(3L, "Elena", "Rodriguez", 9.2));
		
		// Esto no es un error de clave duplicada, ya que save (create-update)
		lista.add(new Alumno(2L, "Jose", "Sanchez", 10));
		
		// Una entidad vacia si que provoca error
		lista.add(new Alumno());
		
		try {
			insertar(lista);
		} catch(Exception ex) {
			System.out.println("Ha ocurrido un error " + ex.getMessage());
		}
		
	}

	@Transactional(propagation = Propagation.REQUIRED,
			isolation = Isolation.SERIALIZABLE,
			rollbackFor = Exception.class)
	public void insertar(List<Alumno> alumnos) {
		
		for (Alumno alumno : alumnos) {
			// El metodo save trata cada insercion como una tx independiente.
			// Por cada entidad ejecuta el commit
			//dao.save(alumno);
		}
		
		// Con saveAll solo hay una tx y si falla pues no creara ningun registro
		dao.saveAll(alumnos);
		
	}
	
	
}












