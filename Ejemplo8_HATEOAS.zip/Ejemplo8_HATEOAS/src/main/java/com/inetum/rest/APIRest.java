package com.inetum.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.inetum.business.ProductosBS;
import com.inetum.models.Producto;

// Metodos estaticos para crear el link
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/api")
public class APIRest {
	
	/*
	 * GET -> Consultas
	 * POST -> Insertar o crear
	 * PUT -> Update o modificar
	 * DELETE -> Eliminar
	 * */
	
	@Autowired
	private ProductosBS business;
	
	// http://localhost:8080/tienda/api
	@GetMapping
	public List<Producto> todos(){
		List<Producto> lista = business.consultarTodos();
		for (Producto producto : lista) {
			String id = producto.getId();
			Link link = linkTo(APIRest.class).slash(id).withSelfRel();
			producto.add(link);
		}
		
		return  lista;
	}
	
	// http://localhost:8080/tienda/api/646c972eaa09000e1dda05ff
	@GetMapping("/{id}")
	public Producto buscar(@PathVariable String id) {
		Producto encontrado = business.buscar(id);
		Link link = linkTo(APIRest.class).slash(id).withSelfRel();
		encontrado.add(link);
		return encontrado;
	}
	
	// http://localhost:8080/tienda/api
	@PostMapping
	public void crear(@RequestBody Producto nuevo) {
		business.insertar(nuevo);
	}
	
	// http://localhost:8080/tienda/api/646c972eaa09000e1dda05ff
	@PutMapping("/{id}")
	public void modificar(@PathVariable String id, @RequestBody Producto producto) {
		business.modificar(id, producto);
	}
	
	// http://localhost:8080/tienda/api/646c972eaa09000e1dda05ff
	@DeleteMapping("/{id}")
	public void eliminar(@PathVariable String id) {
		business.eliminar(id);
	}

}













