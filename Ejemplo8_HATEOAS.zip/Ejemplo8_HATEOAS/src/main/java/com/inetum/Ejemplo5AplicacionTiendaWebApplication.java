package com.inetum;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.inetum.models.Producto;
import com.inetum.persistence.ProductosDAO;


@SpringBootApplication
public class Ejemplo5AplicacionTiendaWebApplication implements CommandLineRunner{
	
	@Autowired
	private ProductosDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo5AplicacionTiendaWebApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		//dao.deleteAll();
		
//		dao.save(new Producto("Pantalla", 150.50));
//		dao.save(new Producto("Teclado", 49.95));
//		dao.save(new Producto("Raton", 18.35));
		
	}

}
