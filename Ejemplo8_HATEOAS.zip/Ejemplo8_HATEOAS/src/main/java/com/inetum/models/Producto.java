package com.inetum.models;

import java.io.Serializable;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.hateoas.RepresentationModel;



@Document
public class Producto extends RepresentationModel<Producto>  implements Serializable {

	@Id
	private String id;
	
	@Size(min = 3, max = 20, message = "Debe tener entre 3 y 20 caracteres")
	private String descripcion;
	
	@Digits(integer = 4, fraction = 2, message = "Debe tener maximo 6 digitos con 2 decimales")
	@DecimalMin(value = "1", message = "Precio minimo 1 €")
	private double precio;

	public Producto() {
		// TODO Auto-generated constructor stub
	}

	public Producto(String descripcion, double precio) {
		super();
		this.descripcion = descripcion;
		this.precio = precio;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Producto [id=" + id + ", descripcion=" + descripcion + ", precio=" + precio + "]";
	}

}
