package com.inetum.business;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.inetum.models.Producto;

@Component(value = "miCarro")
@Scope("session")
public class Carrito implements Serializable{
	
	private List<Producto> contenido = new ArrayList<>();
	private double importe;
	
	@Autowired
	private ProductosBS service;
	
	public void agregarProducto(String id) {
		Producto producto = service.buscar(id);
		contenido.add(producto);
		importe += producto.getPrecio();
	}
	
	
	public void sacarProducto(String id) {
		Producto encontrado = null;
		
		for (Producto p : contenido) {
			if (id.equals(p.getId())) {
				encontrado = p;
				break;
			}
		}
		contenido.remove(encontrado);
		importe -= encontrado.getPrecio();
	}
	
	
	public List<Producto> getContenido() {
		return contenido;
	}
	
	public double getImporte() {
		return importe;
	}

}
