package com.inetum.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.inetum.business.Carrito;

@Controller
@Scope("session")
public class ComprarController {
	
	@Autowired
	private Carrito miCarro;
	
	@RequestMapping(value = "/comprar")
	public String addProducto(@RequestParam("id") String codigo) {
		miCarro.agregarProducto(codigo);
		return "mostrarCarrito";
	}
	
	@RequestMapping(value = "/sacar")
	public String sacarProducto(@RequestParam("id") String codigo) {
		miCarro.sacarProducto(codigo);
		return "mostrarCarrito";
	}

}
