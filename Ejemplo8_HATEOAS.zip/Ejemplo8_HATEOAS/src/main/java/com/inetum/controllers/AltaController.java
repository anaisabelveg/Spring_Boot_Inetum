package com.inetum.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.inetum.business.ProductosBS;
import com.inetum.models.Producto;

@Controller
@RequestMapping("/alta")
public class AltaController {
	
	@Autowired
	private ProductosBS service;
	
	
	@GetMapping
	public String enviarFormulario(Model modelo) {
		// Enviamos al formulario una instancia de Product vacia
		// para que segun se introducen los datos
		// se guarden en las propiedades del objeto prod
		modelo.addAttribute("prod", new Producto());
		return "formAlta";
	}
	
	
	@PostMapping
	public String procesarFormulario(@Valid @ModelAttribute("prod")  Producto producto,
			BindingResult resultado, Model modelo) {
		
		if (resultado.hasErrors()) {
			return "formAlta";
		}
		
		if (service.insertar(producto) == null) {
			modelo.addAttribute("msg", "Lo siento, no se pudo crear el producto");		
		} else {
			modelo.addAttribute("msg", "Producto creado correctamente");
		}
		
		return "mostrarMensaje";
		
	}

}













