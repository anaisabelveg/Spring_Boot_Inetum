package com.inetum;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.inetum.models.Direccion;
import com.inetum.persistence.Cliente;
import com.inetum.persistence.ClientesDAO;

@SpringBootApplication
public class Ejemplo3MongoDbApplication implements CommandLineRunner{
	
	@Autowired
	private ClientesDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo3MongoDbApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		// Borro los datos anteriores
		//dao.deleteAll();
		
		// Alta de clientes
//		dao.save(new Cliente("Transportes Lopez", "11111111-A", 50_000, false, 
//				new Direccion("Mayor", 28, "Madrid")));
//		dao.save(new Cliente("Fruteria Antonio", "22222222-B", 150_000, true, 
//				new Direccion("Diagonal", 80, "Barcelona")));
//		dao.save(new Cliente("Peluqueria Mary", "33333333-C", 800_000, true, 
//				new Direccion("Real", 56, "Valencia")));
//		dao.save(new Cliente("Limpiezas Juan", "44444444-D", 10_000, false, 
//				new Direccion("Recoletos", 35, "Sevilla")));
		
	}
	
	

}
