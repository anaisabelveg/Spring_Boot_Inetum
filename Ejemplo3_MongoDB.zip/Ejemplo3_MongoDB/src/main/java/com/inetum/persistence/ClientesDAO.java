package com.inetum.persistence;

import java.util.Collection;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "clientes", path = "clientes")
public interface ClientesDAO extends MongoRepository<Cliente, String>{
	
	// Mostrar todos los clientes
	// http://localhost:8080/clientes
	
	// Buscar por ID
	// http://localhost:8080/clientes/646c7113db46bc0965d9bf6a
	
	// Metodos heredados de CrudRepository
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/
		
	// Podemos crear metodos personalizados utilizando palabras clave
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repository-query-keywords
	
	
	// Mostrar los clientes VIP
	// http://localhost:8080/clientes/search/findByVip?vip=true
	public List<Cliente> findByVip(@Param("vip") boolean vip);
	public List<Cliente> findByVipIsTrue();
	public List<Cliente> findByVipTrue();
	
	
	// Mostrar los clientes con cifra de ventas menor que 100_000 ordenados por nombre ascendente
	// http://localhost:8080/clientes/search/findByCifraVentasLessThanOrderByNombre?cifra=100000
	public List<Cliente> findByCifraVentasLessThanOrderByNombre(@Param("cifra") double cifra);
	
	
	// Mostrar los clientes que viven en Madrid
	// http://localhost:8080/clientes/search/findByDireccionPoblacion?poblacion=Madrid
	public List<Cliente> findByDireccionPoblacion(@Param("poblacion") String poblacion);
	
	
	// Mostrar los que viven en Valencia o Sevilla
	// http://localhost:8080/clientes/search/findByDireccionPoblacionIn?poblaciones=Valencia&poblaciones=Sevilla
	//public List<Cliente> findByDireccionPoblacionIn(@Param("poblaciones") String[] poblaciones);
	
	// http://localhost:8080/clientes/search/findByDireccionPoblacionIn?poblaciones=Valencia,Sevilla
	//public List<Cliente> findByDireccionPoblacionIn(@Param("poblaciones") String[] poblaciones);
	
	// http://localhost:8080/clientes/search/findByDireccionPoblacionIn?poblaciones=Valencia,Sevilla	
	public List<Cliente> findByDireccionPoblacionIn(@Param("poblaciones") Collection<String> poblaciones);

}







