package com.inetum.services;

import com.inetum.models.Carrito;

public interface ICarritoService {

	Carrito crear(String usuario);
	void agregarItem(String id, Integer cantidad, String usuario);
	Carrito buscar(String usuario);
	void eliminarItem(String id, String usuario);
	
}
