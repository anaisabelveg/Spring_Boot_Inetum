package com.inetum.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.inetum.models.Carrito;
import com.inetum.services.ICarritoService;

@RestController
public class CarritoController {
	

	@Autowired
	private ICarritoService carritoService;
	
	// http://localhost:8003/crear/Pepito
	@PostMapping("/crear/{usuario}")
	public Carrito crear(@PathVariable String usuario) {
		return carritoService.crear(usuario);
	}

	// http://localhost:8003/agregar/id/646dea8627ca1a7f91700a08/cantidad/10/usuario/Pepito
	@PutMapping("/agregar/id/{id}/cantidad/{cantidad}/usuario/{usuario}")	
	public void agregarItem(@PathVariable String id, 
			@PathVariable Integer cantidad, @PathVariable String usuario) {
		carritoService.agregarItem(id, cantidad, usuario);
	}

	// http://localhost:8003/buscar/Pepito
    @GetMapping("/buscar/{usuario}")	
    public Carrito buscar(@PathVariable String usuario) {
    	return carritoService.buscar(usuario);
    }

    // http://localhost:8003/sacar/id/646dea8627ca1a7f91700a08/usuario/Pepito
    @PutMapping("/sacar/id/{id}/usuario/{usuario}")	
    public void eliminarItem(@PathVariable String id, @PathVariable String usuario) {
    	carritoService.eliminarItem(id, usuario);
    }

}
