package com.inetum.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.inetum.models.Item;

@FeignClient(name = "servicio-items", url = "localhost:8002")
public interface ItemClienteFeign {

	
	@GetMapping("/listar")
	public List<Item> consultarTodos();
	
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	public Item crearItem(@PathVariable String id, @PathVariable Integer cantidad);
	
	
}
