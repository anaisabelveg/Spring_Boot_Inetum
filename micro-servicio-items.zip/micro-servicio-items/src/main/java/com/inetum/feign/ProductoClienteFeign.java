package com.inetum.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.inetum.models.Producto;

@FeignClient(name = "servicio-productos", url = "localhost:8001")
public interface ProductoClienteFeign {
	
	// Copio los metodos de ProductoController en el micro-servicio-productos
	
	@GetMapping("/listar")
	public List<Producto> listar();
	
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable String id);

}
