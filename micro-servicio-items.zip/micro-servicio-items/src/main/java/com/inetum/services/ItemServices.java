package com.inetum.services;

import java.util.List;

import com.inetum.models.Item;

public interface ItemServices {
	
	List<Item> consultarTodos();
	Item crearItem(String id, Integer cantidad);

}
