package com.inetum.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.inetum.models.Item;
import com.inetum.services.ItemServices;

@RestController
public class ItemController {
	
	@Autowired
	private ItemServices itemService;
	
	// http://localhost:8002/listar
	@GetMapping("/listar")
	public List<Item> consultarTodos(){
		return itemService.consultarTodos();
	}
	
	// http://localhost:8002/crear/646dea8627ca1a7f91700a08/cantidad/10
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	public Item crearItem(@PathVariable String id, @PathVariable Integer cantidad) {
		return itemService.crearItem(id, cantidad);
	}
}
