package com.inetum;

import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import org.json.JSONObject;

import com.inetum.models.Producto;

@SpringBootApplication
public class Ejemplo6ConsumirRestTemplateApplication{
	
	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	// Esto tambien funciona
//	@Bean
//	public RestTemplate restTemplate(RestTemplateBuilder builder) {
//		return builder.build();
//	}

	@Bean
	public CommandLineRunner run(RestTemplate restTemplate) {		
		return datos -> {
			
			// Eliminar un producto
			//restTemplate.delete("http://localhost:8080/tienda/api/646f17882c431508b476d9ff");
			
			
			// Insertar nuevo producto
			JSONObject nuevo = new JSONObject();
			nuevo.put("descripcion", "Pizarra digital");
			nuevo.put("precio", 550);	
			
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> request = new HttpEntity<String>((String)nuevo.toString(), headers);
			//restTemplate.postForEntity("http://localhost:8080/tienda/api", request, String.class);
			
			
			// Modificar el producto
			JSONObject modificar = new JSONObject();
			modificar.put("descripcion", "Pizarra digital");
			modificar.put("precio", 800);
			request = new HttpEntity<String>((String)modificar.toString(), headers);
			restTemplate.put("http://localhost:8080/tienda/api/646f18632c431508b476da00", request);
			
			
			// Solicitar todos los productos
			Producto[] lista = restTemplate.getForObject("http://localhost:8080/tienda/api", Producto[].class);
			System.out.println("---------------- Nuestro catalogo de productos ------------------");
			for (Producto p : lista) {
				System.out.println(p);
			}
			
			
			// Buscar un producto
			Producto encontrado = 
					restTemplate.getForObject("http://localhost:8080/tienda/api/646dea8627ca1a7f91700a08", Producto.class);
			System.out.println("---------------- Producto encontrado ------------------");
			System.out.println(encontrado);
		};			
	}
	

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo6ConsumirRestTemplateApplication.class, args);
	}


}







