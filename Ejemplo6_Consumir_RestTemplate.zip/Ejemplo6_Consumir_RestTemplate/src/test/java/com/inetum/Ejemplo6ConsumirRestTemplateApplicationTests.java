package com.inetum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplo6ConsumirRestTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
