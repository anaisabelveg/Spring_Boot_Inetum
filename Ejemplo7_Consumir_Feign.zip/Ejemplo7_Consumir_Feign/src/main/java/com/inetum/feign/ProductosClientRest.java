package com.inetum.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.inetum.models.Producto;

@FeignClient(name = "servicio", url = "http://localhost:8080/tienda")
public interface ProductosClientRest {
	
	@GetMapping("/api")
	public List<Producto> consultarTodos();
	
	@GetMapping("/api/{id}")
	public Producto buscar(@PathVariable String id);
	
	@PostMapping("/api")
	public void crear(@RequestBody Producto nuevo);
	
	@DeleteMapping("/api/{id}")
	public void eliminar(@PathVariable String id);
	
	@PutMapping("/api/{id}")
	public void modificar(@PathVariable String id, @RequestBody Producto producto);

}
