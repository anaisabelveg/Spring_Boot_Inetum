package com.inetum;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

import com.inetum.feign.ProductosClientRest;
import com.inetum.models.Producto;

@SpringBootApplication
@EnableFeignClients
public class Ejemplo7ConsumirFeignApplication implements CommandLineRunner{
	
	@Autowired
	private ProductosClientRest clienteFeign;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo7ConsumirFeignApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		// Borrar el producto 
		//clienteFeign.eliminar("646f160c2c431508b476d9fe");
		
		// Insertar el producto
		//clienteFeign.crear(new Producto("Disco Duro externo", 117.95));
		
		// Modificar el precio
		clienteFeign.modificar("646f21e02c431508b476da02", new Producto("Disco Duro externo", 97.95));
		
		System.out.println("--------------- Consultar todos los productos ---------------");
		clienteFeign.consultarTodos().forEach(p -> {
			System.out.println(p);
		});
		
		System.out.println("--------------- Buscar un producto ---------------");
		System.out.println(clienteFeign.buscar("646deeb4d97b360396e48cac"));
		
	}

}
