package com.inetum.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.inetum.models.Carrito;

@FeignClient(name = "servicio-carrito", url = "localhost:8003")
public interface CarritoClienteFeign {
	
	// Copio los metodos de CarritoController en el micro-servicio-carrito
	
	@PostMapping("/crear/{usuario}")
	public Carrito crear(@PathVariable String usuario);
	
	@PutMapping("/agregar/id/{id}/cantidad/{cantidad}/usuario/{usuario}")	
	public void agregarItem(@PathVariable String id, 
			@PathVariable Integer cantidad, @PathVariable String usuario);
	
	@GetMapping("/buscar/{usuario}")	
    public Carrito buscar(@PathVariable String usuario);
	
	@PutMapping("/sacar/id/{id}/usuario/{usuario}")	
    public void eliminarItem(@PathVariable String id, @PathVariable String usuario);
}
