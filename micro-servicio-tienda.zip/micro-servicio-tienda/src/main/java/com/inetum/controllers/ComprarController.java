package com.inetum.controllers;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.inetum.feign.CarritoClienteFeign;

@Controller
public class ComprarController {
	
	@Autowired
	private CarritoClienteFeign clienteFeign;;
	
	@RequestMapping(value = "/comprar")
	public String addProducto(@RequestParam("id") String codigo, 
			@RequestParam("cantidad") Integer cantidad, HttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		String usuario = null;
		for (Cookie cookie : cookies) {
			if ("usuario".equals(cookie.getName())) {
				usuario = cookie.getValue();
			}
		}
		
		if (usuario == null) {
			return "login";
		} else {
			clienteFeign.agregarItem(codigo, cantidad, usuario);
			return "index";
		}
		
	}
	
	@RequestMapping(value = "/sacar")
	public String sacarProducto(@RequestParam("id") String codigo, HttpServletRequest request) {
		Cookie[] cookies = request.getCookies();
		String usuario = null;
		for (Cookie cookie : cookies) {
			if ("usuario".equals(cookie.getName())) {
				usuario = cookie.getValue();
			}
		}
		clienteFeign.eliminarItem(codigo, usuario);
		return "index";
	}

}
