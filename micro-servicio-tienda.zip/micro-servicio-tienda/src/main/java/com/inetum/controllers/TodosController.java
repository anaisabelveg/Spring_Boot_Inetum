package com.inetum.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.inetum.feign.ItemClienteFeign;
import com.inetum.models.Item;

@Controller
@RequestMapping("/")
public class TodosController {
	
	@Autowired
	private ItemClienteFeign clienteFeign;
	
	@RequestMapping(value = "todos")
	public String execute(Model modelo) {
		List<Item> lista = clienteFeign.consultarTodos();
		modelo.addAttribute("lista", lista);
		return "mostrarTodos";
	}

}
