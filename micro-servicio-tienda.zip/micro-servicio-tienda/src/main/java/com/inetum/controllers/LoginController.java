package com.inetum.controllers;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.inetum.feign.CarritoClienteFeign;

@Controller
public class LoginController {
	
	@Autowired
	private CarritoClienteFeign clienteFeign;;
	
	@GetMapping(value = "/login")
	public String mostrarFormulario() {	
		return "formLogin";
	}
	
	@PostMapping(value = "/login")
	public String procesarFormulario(@RequestParam("user") String user, 
			@RequestParam("pw") String pw, HttpServletResponse response) {
			
		// Crear el carrito con el nombre de ese usuario
		clienteFeign.crear(user);
		
		// Guardar el nombre en una cookie
		Cookie cookie = new Cookie("usuario", user);
		cookie.setMaxAge(60*60*24);  // 1 dia
		response.addCookie(cookie);
		
		return "index";
	}

}
