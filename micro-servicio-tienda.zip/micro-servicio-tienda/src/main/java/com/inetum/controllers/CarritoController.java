package com.inetum.controllers;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.inetum.feign.CarritoClienteFeign;
import com.inetum.models.Carrito;

@Controller
public class CarritoController {
	
	@Autowired
	private CarritoClienteFeign carritoFeign;
	
	@GetMapping(value = "/carrito")
	public String buscarCarrito(HttpServletRequest request, Model modelo) {

		Carrito carrito = null;
		
		Cookie[] cookies = request.getCookies();
		String usuario = null;
		for (Cookie cookie : cookies) {
			if ("usuario".equals(cookie.getName())) {
				usuario = cookie.getValue();
			}
		}
		
		if (usuario == null) {
			return "index";
		} else {
			carrito = carritoFeign.buscar(usuario);
			modelo.addAttribute("miCarro", carrito);
			return "mostrarCarrito";
		}
		
	}
	

}
