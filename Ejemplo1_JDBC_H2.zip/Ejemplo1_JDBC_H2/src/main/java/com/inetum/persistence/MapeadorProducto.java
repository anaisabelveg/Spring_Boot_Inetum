package com.inetum.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.inetum.model.Producto;

@Component
public class MapeadorProducto implements RowMapper<Producto>{

	@Override
	public Producto mapRow(ResultSet rs, int rowNum) throws SQLException {
	
		Producto producto = new Producto();
		producto.setId(rs.getInt("ID"));
		producto.setDescripcion(rs.getString("DESCRIPCION"));
		producto.setPrecio(rs.getDouble("PRECIO"));
		return producto;
	}

}
