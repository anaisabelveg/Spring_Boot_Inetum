package com.inetum.persistence;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.inetum.model.Producto;

@Repository
public class ProductosDAO{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private MapeadorProducto mapeadorProducto;
	
	// Crear la tabla
	public void crearTabla() {
		String sql = "CREATE TABLE PRODUCTOS ("
				+ "  ID int,"
				+ "  DESCRIPCION varchar(45),"
				+ "  PRECIO double,"
				+ "  PRIMARY KEY (ID))";
		jdbcTemplate.execute(sql);
	}
	
	//CRUD
	public void insertarProducto(Producto nuevo) {
		String sql = "insert into PRODUCTOS values (?,?,?)";
		jdbcTemplate.update(sql, nuevo.getId(), nuevo.getDescripcion(), nuevo.getPrecio());
	}
	
	
	public List<Producto> consultarTodos(){
		String sql = "select * from PRODUCTOS";
		return jdbcTemplate.query(sql, mapeadorProducto);
	}
	
	public Producto buscarProducto(int id) {
		String sql = "select * from PRODUCTOS where ID=?";
		return jdbcTemplate.queryForObject(sql, mapeadorProducto, id);
	}

}
