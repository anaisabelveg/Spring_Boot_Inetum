package com.inetum;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.inetum.model.Producto;
import com.inetum.persistence.ProductosDAO;

@SpringBootApplication
public class Ejemplo1JdbcApplication implements CommandLineRunner{
	
	@Autowired
	private ProductosDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo1JdbcApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		dao.crearTabla();
		
		dao.insertarProducto(new Producto(1, "Pantalla", 135.50));
		dao.insertarProducto(new Producto(2, "Raton", 29.95));
		dao.insertarProducto(new Producto(3, "Teclado", 56.90));
		
		
		// Buscar el producto 2
		System.out.println(dao.buscarProducto(2));
		System.out.println("-----------------------");
		
		// Consultar todos los productos
		for(Producto p: dao.consultarTodos()) {
			System.out.println(p);
		}
		
		
	}

}
