package com.inetum;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.inetum.model.EstadoCivil;
import com.inetum.persistence.Persona;
import com.inetum.persistence.PersonasDAO;

@SpringBootApplication
public class Ejemplo2JpaApplication implements CommandLineRunner{
	
	@Autowired
	private PersonasDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo2JpaApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
	
		dao.save(new Persona("Felipe", "Torres", 'H', 37, EstadoCivil.CASADO, new Date(1985, 11, 23), 
				"Abogado. Licenciado en la Universidad Complutense de Madrid"));
		dao.save(new Persona("Maria", "Lopez", 'M', 42, EstadoCivil.DIVORCIADO, new Date(1982, 9, 14), 
				"Enfermera. Licenciada en la Universidad Carlos III de Madrid"));
		dao.save(new Persona("Juan", "Arias", 'H', 25, EstadoCivil.CASADO, new Date(1985, 11, 23), 
				"Periodista. Licenciado en la Universidad Complutense de Madrid"));
		dao.save(new Persona("Antonia", "Sanchez", 'M', 56, EstadoCivil.DIVORCIADO, new Date(1967, 4, 18), 
				"Informatica. Licenciada en la Universidad Politecnica de Madrid"));
		
		System.out.println("Tengo " + dao.count() + " registros en mi tabla");
		
	}

}
