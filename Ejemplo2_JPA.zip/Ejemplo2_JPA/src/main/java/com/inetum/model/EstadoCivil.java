package com.inetum.model;

public enum EstadoCivil {
	
	SOLTERO, CASADO, VIUDO, DIVORCIADO, PAREJA_HECHO;

}
