package com.inetum.persistence;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "personas", path = "personas")
public interface PersonasDAO extends CrudRepository<Persona, Long>{
	
	// Mostrar todas las personas
	// http://localhost:8080/personas
	
	// Buscar una persona por su id
	// http://localhost:8080/personas/2
	
	// Metodos heredados de CrudRepository
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/
	
	// Podemos crear metodos personalizados utilizando palabras clave
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repository-query-keywords
	
	// Para ver en el navegador todos los metodos creados
	// http://localhost:8080/personas/search
	
	// http://localhost:8080/personas/search/findBySexo?sexo=M
	// Buscar personas por sexo
	public List<Persona> findBySexo(@Param("sexo") char sexo);
	
	
	// Mostrar todas ordenados por apellido Ascendente
	// http://localhost:8080/personas/search/OrderByApellido
	public List<Persona> OrderByApellido();
	
	
	// Mostrar todas ordenados por apellido descendente
	// http://localhost:8080/personas/search/OrderByApellidoDesc
	public List<Persona> OrderByApellidoDesc();
	
	
	// Mostrar todas con edad comprendida entre min y max
	// http://localhost:8080/personas/search/findByEdadBetween?min=25&max=55
	public List<Persona> findByEdadBetween(@Param("min") int min, @Param("max") int max);
	
	
	// Mostrar todas con edad superior a 50
	// http://localhost:8080/personas/search/findByEdadGreaterThan?edad=50
	public List<Persona> findByEdadGreaterThan(@Param("edad") int edad);

}












