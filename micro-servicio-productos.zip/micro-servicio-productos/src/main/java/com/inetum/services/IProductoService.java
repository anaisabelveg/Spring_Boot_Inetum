package com.inetum.services;

import java.util.List;

import com.inetum.models.Producto;

public interface IProductoService {
	
	List<Producto> consultarTodos();
	Producto buscarProducto(String id);

}
