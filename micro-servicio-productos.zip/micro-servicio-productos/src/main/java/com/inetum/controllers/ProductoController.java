package com.inetum.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.inetum.models.Producto;
import com.inetum.services.IProductoService;

@RestController
public class ProductoController {
	
	@Autowired
	private IProductoService productoServices;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return productoServices.consultarTodos();
	}
	
	// http://localhost:8001/buscar/646dea8627ca1a7f91700a08
	@GetMapping("/buscar/{id}")
	public Producto buscar(@PathVariable String id) {
		return productoServices.buscarProducto(id);
	}

}
