package com.inetum.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.inetum.business.ProductosBS;
import com.inetum.models.Producto;

@Controller
@RequestMapping("/buscar")
public class BuscarController {
	
	@Autowired
	private ProductosBS service;
	
	
	@GetMapping
	public String enviarFormulario(Model modelo) {
		// Enviamos al formulario una instancia de Product vacia
		// para que segun se introducen los datos
		// se guarden en las propiedades del objeto prod
		modelo.addAttribute("prod", new Producto());
		return "formBuscar";
	}
	
	
	@PostMapping
	public String procesarFormulario(@ModelAttribute("prod")  Producto producto,
			Model modelo) {
		Producto encontrado = service.buscar(producto.getId());
		
		if (encontrado == null) {
			modelo.addAttribute("msg", "Lo siento, ese producto no lo tenemos");
			return "mostrarMensaje";
		} else {
			modelo.addAttribute("encontrado", encontrado);
			return "mostrarProducto";
		}
		
	}

}













