package com.inetum.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.inetum.business.ProductosBS;
import com.inetum.models.Producto;

@RestController
public class APIRest {
	
	/*
	 * GET -> Consultas
	 * POST -> Insertar o crear
	 * PUT -> Update o modificar
	 * DELETE -> Eliminar
	 * */
	
	@Autowired
	private ProductosBS business;
	
	// http://localhost:8080/tienda/api
	@GetMapping("/api")
	public List<Producto> todos(){
		return  business.consultarTodos();
	}
	
	// http://localhost:8080/tienda/api/646c972eaa09000e1dda05ff
	@GetMapping("/api/{id}")
	public Producto buscar(@PathVariable String id) {
		return business.buscar(id);
	}
	
	@PostMapping("/api")
	public void crear(@RequestBody Producto nuevo) {
		business.insertar(nuevo);
	}
	
	@PutMapping("/api/{id}")
	public void modificar(@PathVariable String id, @RequestBody Producto producto) {
		business.modificar(id, producto);
	}
	
	@DeleteMapping("/api/{id}")
	public void eliminar(@PathVariable String id) {
		business.eliminar(id);
	}

}













