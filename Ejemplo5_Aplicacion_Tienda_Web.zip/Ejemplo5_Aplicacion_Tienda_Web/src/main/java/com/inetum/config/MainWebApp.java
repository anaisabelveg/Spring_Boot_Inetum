package com.inetum.config;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;


public class MainWebApp implements WebApplicationInitializer{

	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		/*
		System.out.println("------------- HOLA -----------");
		
		AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext();
		
		// Forzar a que se generen los beans
		context.scan("com.inetum");
		
		servletContext.addListener(new ContextLoaderListener(context));
		
		
		ServletRegistration.Dynamic dispatcher = 
				servletContext.addServlet("mvc", new DispatcherServlet(context));
		
		// El ciclo de vida del servlet comienza cuando arranca la aplicacion
		dispatcher.setLoadOnStartup(1);
		
		// Este servlet va a atender todas las peticiones que comienzan con /
		dispatcher.addMapping("/");
		*/
		
	}

}
