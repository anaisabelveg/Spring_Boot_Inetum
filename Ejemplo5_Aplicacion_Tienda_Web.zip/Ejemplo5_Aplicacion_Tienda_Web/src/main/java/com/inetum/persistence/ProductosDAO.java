package com.inetum.persistence;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.inetum.models.Producto;


@RepositoryRestResource(collectionResourceRel = "productos", path = "productos")
public interface ProductosDAO extends MongoRepository<Producto, String>{

}
